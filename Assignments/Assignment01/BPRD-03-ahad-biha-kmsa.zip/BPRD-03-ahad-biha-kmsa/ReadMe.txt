﻿Exercise 3.3
See file Answer3.3.txt for answer.


Exercise 3.4
See file Answer3.4.pdf for derivation tree.


Exercise 3.5
See file Answer3.5.txt for answer.
We have written what we put into the F# interactive and below the answer we got.
Our own created tests are at the bottom.

Exercise 3.6
See bottom of Expr.fs 
What we wrote is marked with
#region
    [Code]
#endregion


Exercise 3.7
See Absyn.fs, ExprLex.fsl and ExprPar.fsy for our answer.
What we wrote are either marked with a single comment at the line we added or:
(*#region Exercise 3.7*)
(*#endregion*)


