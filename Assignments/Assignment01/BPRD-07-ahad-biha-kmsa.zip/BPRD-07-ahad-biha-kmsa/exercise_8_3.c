﻿void main(int i)
{
    int e;
    e = 0;
    print e;
    e = ++i;
    print i;
    print e;
}