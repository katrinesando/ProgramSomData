﻿void main(int n) {
    int result;
    result = (n == 1 ? 1 : 0);
    print result;
}